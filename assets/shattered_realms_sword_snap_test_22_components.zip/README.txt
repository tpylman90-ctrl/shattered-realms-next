SWORD SNAP TEST — 22 INDIVIDUAL TRANSPARENT PNG FILES

10 framework and 12 striker cutouts, 512x512 RGBA, names aligned to the current Sword family catalog.
This is an isolated prototype pack. Extract to the root of the feature/android-forge-build repo under assets/entropic_forge/snap_test/sword/.
These are GRID CUTOUTS for alignment experiments, not finished production assets. The blade sheet has guard/handle pieces already baked in and some items cross cell boundaries; manual cleanup/redraw needed before final assembly system.
The manifest includes trial normalized snap anchors for initial alignment experiments. No existing item icon mapping is overwritten.
